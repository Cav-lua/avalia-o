package com.example.avaliaomobile;

import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {

    private EditText etPassos;
    private RadioGroup rgTamanhoPasso;
    private CheckBox cbCorrida;
    private Button btnCalcular;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        etPassos = findViewById(R.id.etPassos);
        rgTamanhoPasso = findViewById(R.id.rgTamanhoPasso);
        cbCorrida = findViewById(R.id.cbCorrida);
        btnCalcular = findViewById(R.id.btnCalcular);
        tvResultado = findViewById(R.id.tvResultado);


        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularDistancia();
            }
        });
    }

    private void calcularDistancia() {
        String passosStr = etPassos.getText().toString();


        if (passosStr.isEmpty()) {
            Toast.makeText(this, "Por favor, insira a quantidade de passos.", Toast.LENGTH_SHORT).show();
            return;
        }

        int passos = Integer.parseInt(passosStr);


        double tamanhoPasso = 0;
        int selectedId = rgTamanhoPasso.getCheckedRadioButtonId();
        if (selectedId == R.id.rbCurto) {
            tamanhoPasso = 0.5;
        } else if (selectedId == R.id.rbMedio) {
            tamanhoPasso = 0.7;
        } else if (selectedId == R.id.rbLongo) {
            tamanhoPasso = 1.0;
        } else {
            Toast.makeText(this, "Por favor, selecione o tamanho do passo.", Toast.LENGTH_SHORT).show();
            return;
        }


        double distancia = passos * tamanhoPasso;


        if (cbCorrida.isChecked()) {
            distancia *= 1.1;
        }


        tvResultado.setText("Distância percorrida: " + String.format("%.2f", distancia) + " metros");
    }
}